from django.shortcuts import render, redirect
from .models import Category, Todo
from .forms import TodoForm
from datetime import datetime

def add_todo(request):

    # GET
    todo_form = TodoForm()
    
    # POST
    if request.method == 'POST':

        todo_form_filled = TodoForm(request.POST)
        todo_form_filled.save()

        return redirect('todos')

    context = {'form': todo_form}
    return render(request, 'add_todo.html', context)


def all_todos(request):

    done = Todo.objects.filter(has_been_done=True)
    not_done = Todo.objects.filter(has_been_done=False)

    context = {'todos_done': done, 'todos_not_done': not_done}

    return render(request, 'todo_list.html', context)


def complete_todo(request, id):

    todo = Todo.objects.get(id=id)
    todo.has_been_done = True
    todo.date_completion = datetime.now()

    todo.save()

    return redirect(to='todos')

